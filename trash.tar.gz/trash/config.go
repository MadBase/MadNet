package MadNet

// Config returns a useless string, but usefully it sets the package
func Config() string {
	return "MadNet"
}
