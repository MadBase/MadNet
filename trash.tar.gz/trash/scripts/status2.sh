#!/bin/sh
./madnet --config ./assets/config/validator2.toml --logging ethereum=error,utils=info utils
