#!/bin/sh
./madnet --config ./assets/config/validator2.toml validator
