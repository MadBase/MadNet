#!/bin/sh
./madnet --config ./assets/config/validator3.toml validator
