#!/bin/sh
./madnet --config ./assets/config/validator1.toml validator
