#!/bin/sh
./madnet --config ./assets/config/validator4.toml validator
