#!/bin/sh
./madnet --config ./assets/config/owner.toml utils deposit
