#!/bin/sh
./madnet --config ./assets/config/validator0.toml validator
