#!/bin/sh
./madnet --config ./assets/config/validator4.toml --logging ethereum=error,utils=info utils
