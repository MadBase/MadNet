#!/bin/sh
./madnet --config ./assets/config/validator1.toml --logging ethereum=error,utils=info utils
