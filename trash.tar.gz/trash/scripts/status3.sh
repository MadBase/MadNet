#!/bin/sh
./madnet --config ./assets/config/validator3.toml --logging ethereum=error,utils=info utils
